export class User {
     name:string
    }