export const Config ={
    API_ENDPOINT:"http://localhost:3500/api",
    AUTH_TOKEN:'abcdxyz@123'
}