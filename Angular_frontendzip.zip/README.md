search-project


Make sure you have these installed:

1.node.js

2.git

Clone this repository into your local machine using the terminal (mac) or Gitbash (PC) > git clone https://github.com/lavanyaMEAN/Angular_frontend

CD to the folder cd angular_frontend

Run > npm install to install the project dependencies

Running unit tests:

Run "ng test" to execute the unit tests via Karma.

About This Application:

This application searches customer names with a given search term

